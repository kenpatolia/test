<?php

namespace Drupal\pfg_design_system\Plugin\Block;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\pfg_design_system\Element\PdsLink;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'Content Block' block.
 *
 * @Block(
 *   id = "pfg_design_system_line_break_support_section",
 *   admin_label = @Translation("Line Break Support"),
 *   category = @Translation("Principal Design System"),
 * )
 *
 * @method static \Drupal\media\MediaInterface loadEntityBrowserEntity($id)
 */
class LineBreakSupportSection extends PdsBlockBase implements ContainerFactoryPluginInterface {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The module handler.
   *
   * @var \Drupal\Core\Extension\ModuleHandlerInterface
   */
  protected $moduleHandler;

  /**
   * {@inheritdoc}
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, EntityTypeManagerInterface $entityTypeManager, ModuleHandlerInterface $moduleHandler) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entityTypeManager;
    $this->moduleHandler = $moduleHandler;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('module_handler')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'variant' => '',
      // 'class' => [],
      'eyebrow_text' => '',
      'heading_text' => '',
      'content_text' => [
        'value' => '',
        'format' => 'full_html',
      ],
      // Phone number.
      'phone_text' => '',
      'support_content' => [
        'value' => '',
        'format' => 'full_html',
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $content = [
      '#type' => 'pds_line_break_support_section',
      // '#class' => $this->configuration['class'],
      '#eyebrow_text' => $this->configuration['eyebrow_text'],
      '#heading_text' => $this->configuration['heading_text'],
      '#content_text' => $this->configuration['content_text'],
      // Phone number.
      '#phone_text' => $this->configuration['phone_text'],
      '#support_content' => $this->configuration['support_content'],
      '#variant' => $this->configuration['variant'],
    ];

    return $content;
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state): array {
    $form = parent::blockForm($form, $form_state);

    $form['variant'] = [
      '#type' => 'select',
      '#title' => $this->t('Variant'),
      '#options' => [
        'default' => $this->t('Default'),
        'nextSteps' => $this->t('Next Steps'),
      ],
      '#default_value' => $this->configuration['variant'],
    ];
    $form['eyebrow_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Eyebrow text'),
      '#default_value' => $this->configuration['eyebrow_text'],
    ];
    $form['eyebrow_text']['#states']['visible'] = [
        'select[name="settings[variant]"]' => ['value' => 'default'],
    ];
    $form['heading_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Heading Text'),
      '#default_value' => $this->configuration['heading_text'],
    ];
    $form['content_text'] = [
      '#type' => 'text_format',
      '#title' => $this->t('Content'),
      '#format' => $this->configuration['content_text']['format'],
      '#default_value' => $this->configuration['content_text']['value'],
    ];

    $form['phone_text'] = [
      '#type' => 'tel',
      '#title' => $this->t('Phone Number (formatted)'),
      '#default_value' => $this->configuration['phone_text'],
      '#description' => $this->t("Number should be entered as <span class='pds-phone-pattern'>XXX-XXX-XXXX</span>. <a href=\"https://design.principal.com/brand/editorial/grammar-punctuation#numbers\" target=\"_blaknk\" title=\"Opens in a new window\">Phone number guidance.</a>"),
    ];
    $form['phone_text']['#states']['visible'] = [
      'select[name="settings[variant]"]' => ['value' => 'default'],
    ];

    // This should only display if there is a phone_text.
    // @todo change behavior based on the variant.
    $form['support_content'] = [
      '#type' => 'text_format',
      '#title' => $this->t('Support text'),
      '#format' => $this->configuration['support_content']['format'],
      '#default_value' => $this->configuration['support_content']['value'],
      '#description' => $this->t('First line should point to name of directory. Second line should name day/hours.'),
      // '#states' => [
      //   'visible' => [
      //     ':input[name="settings[phone_text]"]' => ['!value' => ''],
      //   ],
      // ],
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    parent::blockSubmit($form, $form_state);

    // $this->configuration['class'] = $form_state->getValue('class');
    $this->configuration['eyebrow_text'] = ($form_state->getValue('variant') == 'nextSteps') ? '' : $form_state->getValue('eyebrow_text');
    $this->configuration['heading_text'] = $form_state->getValue('heading_text');
    $this->configuration['content_text'] = $form_state->getValue('content_text');
    $this->configuration['phone_text'] = $form_state->getValue('phone_text');
    $this->configuration['support_content'] = $form_state->getValue('support_content');
    $this->configuration['variant'] = $form_state->getValue('variant');
    // If we don't have a phone number, nullify the phone_content.
    if (empty($form_state->getValue('phone_text'))) {
      $this->configuration['support_text'] = NULL;
    }


  }

}
