<?php

namespace Drupal\pfg_design_system\Element;

use Drupal\Core\Render\Element\RenderElement;

/**
 * Provides a render element for line break support sections.
 *
 * @RenderElement("pds_line_break_support_section")
 */
class PdsLineBreakSupportSection extends RenderElement {

  /**
   * {@inheritdoc}
   */
  public function getInfo() {
    $class = get_class($this);
    return [
      '#component_attributes' => [],
      '#eyebrow_text' => '',
      '#heading_text' => '',
      '#content_text' => '',
      '#phone_content' => '',
      '#process' => [
        [$class, 'processGroup'],
        [$class, 'processPdsLineBreakSupportSection'],
      ],
      '#pre_render' => [
        [$class, 'preRenderGroup'],
        [$class, 'preRenderPdsLineBreakSupportSection'],
      ],
      '#theme' => 'pds_line_break_support_section',
    ];
  }

  /**
   * Pre-renders the line break support element.
   *
   * @param array $element
   *   An associative array containing the properties and children of the
   *   container.
   *
   * @return array
   *   The modified element.
   */
  public static function preRenderPdsLineBreakSupportSection(array $element) {
    $element['#attached']['library'][] = 'pfg_design_system/lineBreakSupportSection';
    $element['#attached']['library'][] = 'pfg_design_system/divider';

    // Format the eyebrow/typography class.
    // if (is_array($element['#typography']['classes'])) {
    //   $element['#typography']['classes'] = implode(' ', $element['#typography']['classes']);
    // }

    $element['#component_attributes']['class'][] = 'pds-lineBreakSupportSection-' . $element['#variant'];

    // Format the text_format fields.
    $element['#content_text'] = check_markup($element['#content_text']['value'], $element['#content_text']['format']);
    return $element;
  }

}
